"""Container entrypoint: wait for the database, run migrations, then start uvicorn.

Replaces the old `sh -c "alembic upgrade head && exec uvicorn ..."` one-liner, which crashed the container
(and failed the deploy) whenever Postgres was not accepting connections yet.
Run with: python -m app.entrypoint
"""
from __future__ import annotations

import asyncio
import os
import subprocess
import sys
import time

from sqlalchemy import text
from sqlalchemy.ext.asyncio import create_async_engine
from sqlalchemy.pool import NullPool

from app.database import normalize_database_url, split_connect_args

DB_WAIT_SECONDS = int(os.environ.get("DB_WAIT_SECONDS", "60"))
MIGRATION_RETRIES = int(os.environ.get("MIGRATION_RETRIES", "3"))


def log(msg: str) -> None:
    print(f"[entrypoint] {msg}", flush=True)


async def _ping(url: str) -> None:
    clean_url, connect_args = split_connect_args(normalize_database_url(url))
    engine = create_async_engine(clean_url, poolclass=NullPool, connect_args=connect_args)
    try:
        async with engine.connect() as conn:
            await conn.execute(text("SELECT 1"))
    finally:
        await engine.dispose()


def wait_for_database(url: str, timeout: int = DB_WAIT_SECONDS) -> None:
    deadline = time.monotonic() + timeout
    delay = 1.0
    while True:
        try:
            asyncio.run(_ping(url))
            log("database is reachable")
            return
        except Exception as exc:  # noqa: BLE001 - any connection problem means "not ready yet"
            if time.monotonic() + delay > deadline:
                log(f"database not reachable after {timeout}s: {type(exc).__name__}")
                sys.exit(1)
            log(f"waiting for database ({type(exc).__name__}); retry in {delay:.0f}s")
            time.sleep(delay)
            delay = min(delay * 2, 8.0)


def run_migrations() -> None:
    for attempt in range(1, MIGRATION_RETRIES + 1):
        result = subprocess.run([sys.executable, "-m", "alembic", "upgrade", "head"])
        if result.returncode == 0:
            log("migrations applied")
            return
        log(f"alembic failed (attempt {attempt}/{MIGRATION_RETRIES})")
        time.sleep(2 * attempt)
    sys.exit("migrations failed; refusing to start")


def main() -> None:
    url = os.environ.get("DATABASE_URL", "").strip()
    if not url:
        sys.exit("DATABASE_URL is not set")
    if os.environ.get("SKIP_MIGRATIONS", "").lower() not in {"1", "true", "yes"}:
        wait_for_database(url)
        run_migrations()
    port = os.environ.get("PORT", "8080")
    log(f"starting uvicorn on port {port}")
    os.execvp(sys.executable, [
        sys.executable, "-m", "uvicorn", "app.main:create_app", "--factory",
        "--host", "0.0.0.0", "--port", port,
        "--proxy-headers", "--forwarded-allow-ips", "*",
        "--timeout-graceful-shutdown", "8",
    ])


if __name__ == "__main__":
    main()
